package usainbelt.affichage;

import usainbelt.javaarduino.tdtp.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static usainbelt.affichage.Main.lissageExponentiel;

public class Bdd {

    // À adapter à votre BD
    private final String serveurBD = "fimi-bd-srv1.insa-lyon.fr";
    private final String portBD = "3306";
    private final String nomBD = "G223_A_BD1";
    private final String loginBD = "G223_A";
    private final String motdepasseBD = "G223_A";

    private static Connection connection = null;
    private static PreparedStatement selectUserDataStatement = null;
    private static PreparedStatement userExistsStatement = null;
    private static PreparedStatement selectLastSeanceStatement = null;
    private static PreparedStatement selectSeanceDataStatement = null;
    private static PreparedStatement selectVitesseMaxMinStatement = null;
    private static PreparedStatement selectVitessesInstant = null;
    private static PreparedStatement selectDistantTotSeptDeniers = null;
    private static PreparedStatement selectVitesseMoySeptDeniers = null;

    public void connexionBD() throws Exception {

        try {
            String urlJDBC = "jdbc:mysql://" + this.serveurBD + ":" + this.portBD + "/" + this.nomBD;
            urlJDBC += "?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=Europe/Paris";

            //System.out.println("Connexion à " + urlJDBC);
            connection = DriverManager.getConnection(urlJDBC, this.loginBD, this.motdepasseBD);

            //System.out.println("Connexion établie...");
            // Requête de test pour lister les tables existantes dans les BDs MySQL
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT table_schema, table_name"
                    + " FROM information_schema.tables"
                    + " WHERE table_schema NOT LIKE '%_schema' AND table_schema != 'mysql'"
                    + " ORDER BY table_schema, table_name");
            ResultSet result = statement.executeQuery();

            //System.out.println("Liste des tables:");
            while (result.next()) {
                //System.out.println("- " + result.getString("table_schema") + "." + result.getString("table_name"));
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
            throw new Exception("Erreur dans la méthode connexionBD()");
        }

    }

    public void fermetureConnexionBD() throws Exception {

        try {
            if (this.connection != null) {

                this.connection.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
            throw new Exception("Erreur dans la méthode fermetureConnexionBD()");
        }

    }

    public void creerRequetesParametrees() throws Exception {
        try {
            selectUserDataStatement = connection.prepareStatement("SELECT * FROM Utilisateur WHERE idUtilisateur =?");
            userExistsStatement = connection.prepareStatement("SELECT EXISTS(SELECT * from Utilisateur WHERE idUtilisateur = ?) AS reponse");
            selectLastSeanceStatement = connection.prepareStatement("SELECT * FROM Seance WHERE idUtilisateur=? AND dateFin IS NOT NULL ORDER BY dateDebut DESC LIMIT ?");
            selectSeanceDataStatement = connection.prepareStatement("SELECT * FROM Seance WHERE idSeance =?");
            selectVitesseMaxMinStatement = connection.prepareStatement("SELECT * FROM (SELECT MAX(vitesseInstant) AS MAX FROM Mesure WHERE idSeance=?) AS MAX, (SELECT MIN(vitesseInstant) AS MIN FROM Mesure WHERE idSeance=?) AS MIN");
            selectVitessesInstant = connection.prepareStatement("SELECT dateMesure, vitesseInstant FROM Mesure WHERE idSeance = ?");
            selectVitesseMoySeptDeniers = connection.prepareStatement("SELECT AVG(vitesseMoy) moy FROM (SELECT vitesseMoy FROM Seance WHERE idUtilisateur=? AND vitesseMoy IS NOT NULL ORDER BY dateDebut DESC LIMIT 7) as res");
            selectDistantTotSeptDeniers = connection.prepareStatement("SELECT SUM(distanceParcourue) sum FROM (SELECT distanceParcourue FROM Seance WHERE idUtilisateur=? AND distanceParcourue IS NOT NULL ORDER BY dateDebut DESC LIMIT 7) AS res");
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
            throw new Exception("Erreur dans la méthode creerRequetesParametrees()");
        }
    }

    public String[] getUserInfo(int idUser) {
        // Renvoie un tableau avec (nom, age, poids, taille, genre, idCeinture)
        String[] res = new String[6];
        try {
            selectUserDataStatement.setInt(1, idUser);
            ResultSet result = selectUserDataStatement.executeQuery();
            while (result.next()) {
                res[0] = result.getString("nom");
                res[1] = Integer.toString(result.getInt("age"));
                res[2] = Integer.toString(result.getInt("poids"));
                res[3] = Integer.toString(result.getInt("taille"));
                int genre = 0;
                if (result.getBoolean("genre")) {
                    genre = 1;
                }
                res[4] = Integer.toString(genre);
                res[5] = Integer.toString(result.getInt("idCeinture"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(new JFrame(), "L'utilisateur n'est pas inscrit !", "Erreur d'authenfication",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace(System.err);
        }
        return res;
    }

    public boolean userExists(int idUser) {
        int res = 0;
        try {
            userExistsStatement.setInt(1, idUser);
            ResultSet result = userExistsStatement.executeQuery();
            while (result.next()) {
                res = result.getInt("reponse");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        if (res == 1) {
            return true;
        } else {
            return false;
        }
    }

    public static int getLastSeance(int idUser) {
        int res = -1;
        try {
            selectLastSeanceStatement.setInt(1, idUser);
            selectLastSeanceStatement.setInt(2, 1);
            ResultSet result = selectLastSeanceStatement.executeQuery();

            while (result.next()) {
                res = (result.getInt("idSeance"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        return res;
    }

    public String[] getSeanceInfo(int idSeance) {
        // Renvoie un tableau avec (duree(h), idUtilisateur, vitesseMoy, distanceParcourue)
        String[] res = new String[4];
        try {
            selectSeanceDataStatement.setInt(1, idSeance);
            ResultSet result = selectSeanceDataStatement.executeQuery();
            while (result.next()) {
                Date debut = new Date(result.getTimestamp("dateDebut").getTime());
                Date fin = debut;
                if (result.getTimestamp("dateFin") != null) { // On vérifie si la séance est terminée
                    fin = new Date(result.getTimestamp("dateFin").getTime());
                }
                double dureeMin = (fin.getTime() / (1000 * 60)) - (debut.getTime() / (1000 * 60));
                double dureeHeure = dureeMin / 60;
                res[0] = Double.toString(dureeHeure);
                res[1] = Integer.toString(result.getInt("idUtilisateur"));
                res[2] = Double.toString(Main.arrondir(result.getDouble("vitesseMoy"), 2));
                res[3] = Double.toString(Main.arrondir(result.getDouble("distanceParcourue"), 1));
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        return res;
    }

    public double[] getVitessesMaxMin(int idSeance) {
        // Renvoie un tableau avec la vitesse max et min d'une séance
        double[] res = new double[2];
        try {
            selectVitesseMaxMinStatement.setInt(1, idSeance);
            selectVitesseMaxMinStatement.setInt(2, idSeance);
            ResultSet result = selectVitesseMaxMinStatement.executeQuery();
            while (result.next()) {
                res[1] = result.getDouble("MAX");
                res[0] = result.getDouble("MIN");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        return res;
    }

    public LinkedList<double[]> vitessesSeance(int idSeance) {
        LinkedList<double[]> valeurs = new LinkedList<double[]>();
        int secondeInitiale = 0;
        double[] valeur = new double[2];
        Date dateMesure;
        try {
            selectVitessesInstant.setInt(1, idSeance);
            ResultSet result = selectVitessesInstant.executeQuery();
            if (result.next()) { // Première mesure
                dateMesure = new Date(result.getTimestamp("dateMesure").getTime());
                secondeInitiale = (int) (dateMesure.getTime() / 1000);
                valeur[0] = 0;
                valeur[1] = result.getDouble("vitesseInstant");

                valeurs.add(valeur);
            }
            while (result.next()) {
                dateMesure = new Date(result.getTimestamp("dateMesure").getTime());
                valeur = new double[2];
                valeur[0] = ((dateMesure.getTime() / 1000) - secondeInitiale);
                valeur[1] = result.getDouble("vitesseInstant");
                valeurs.add(valeur);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        if (valeurs.isEmpty()) {
            double[] v = {0, 0};
            valeurs.add(v);
        }
        // lissage
        LinkedList<Double> vitesses = new LinkedList<Double>();
        for (double[] v : valeurs) {
            vitesses.add(v[1]);
        }
        vitesses = lissageExponentiel(vitesses, 0.1);
        for (int i = 0; i < valeurs.size(); i++) {
            double[] t = new double[2];
            t[0] = valeurs.get(i)[0];
            t[1] = vitesses.get(i);
            valeurs.set(i, t);
        }
        return valeurs;
    }

    public LinkedList<String> septDernieresDates(int idUser) {
        LinkedList<String> res = new LinkedList<String>();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM HH:mm");
        Date dateSeance;
        try {
            selectLastSeanceStatement.setInt(1, idUser);
            selectLastSeanceStatement.setInt(2, 7);
            ResultSet result = selectLastSeanceStatement.executeQuery();
            while (result.next()) {
                dateSeance = new Date(result.getTimestamp("dateDebut").getTime());
                res.add(dateFormat.format(dateSeance));
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        Collections.reverse(res);
        return res;
    }

    public LinkedList<Double> septDernieresDistances(int idUser) {
        LinkedList<Double> res = new LinkedList<Double>();
        try {
            selectLastSeanceStatement.setInt(1, idUser);
            selectLastSeanceStatement.setInt(2, 7);
            ResultSet result = selectLastSeanceStatement.executeQuery();
            while (result.next()) {
                res.add(result.getDouble("distanceParcourue"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }

        // la derniere valeur est le max de la liste
        double max = 0;
        if(!res.isEmpty()){
            max = res.get(0);
        }
        for (double dist : res) {
            if (dist > max) {
                max = dist;
            }
        }
        res.add(max);
        Collections.reverse(res); // Le max de la liste est le premier élément
        return res;
    }

    public String distanceTotalSeptDerniers(int idUser) {
        String res = "";
        try {
            selectDistantTotSeptDeniers.setInt(1, idUser);
            ResultSet result = selectDistantTotSeptDeniers.executeQuery();
            while (result.next()) {
                res = Double.toString(Main.arrondir(result.getDouble("sum"), 1));
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        return res;
    }

    public String vitesseMoySeptDerniers(int idUser) {
        String res = "";
        try {
            selectVitesseMoySeptDeniers.setInt(1, idUser);
            ResultSet result = selectVitesseMoySeptDeniers.executeQuery();
            while (result.next()) {
                Double vitesseMoy = result.getDouble("moy"); // en km/h
                vitesseMoy = vitesseMoy / 60; // en km/min
                vitesseMoy = 1 / vitesseMoy; // en min/km = allure
                res = Double.toString(Main.arrondir(vitesseMoy, 1));
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.err);
        }
        return res;
    }

    public String getCalories(int idUser, Double duree, int vitesseMoy) {
        double kcal = 0;
        // durée en HEURE, vitesseMoy en kmh
        int genre = Integer.parseInt(getUserInfo(idUser)[4]);
        int age = Integer.parseInt(getUserInfo(idUser)[1]);
        int taille = Integer.parseInt(getUserInfo(idUser)[3]); // en cm
        int poids = Integer.parseInt(getUserInfo(idUser)[2]); // en kg
        if (genre == 0) { // garçon
            kcal = (13.397 * poids + 4.799 * taille - 5.677 * age + 88.362) * (0.0486 * vitesseMoy + 0.093) * (duree / 24);
        }
        if (genre == 1) {// fille
            kcal = (9.247 * poids + 3.098 * taille - 4.330 * age + 447.593) * (0.0486 * vitesseMoy + 0.093) * (duree / 24);
        }
        return Double.toString(Main.arrondir(kcal, 1));
    }

    public int[] getBpmMaxMin(int idSeance) {
        String query = "SELECT * FROM (SELECT MAX(freqCardiaque) AS MAX FROM Mesure WHERE idSeance=?) AS MAX, (SELECT MIN(freqCardiaque) AS MIN FROM Mesure WHERE idSeance=?) AS MIN";
        int[] res = new int[2];
        try {
            PreparedStatement bpmMaxMinStatement = connection.prepareStatement(query);
            bpmMaxMinStatement.setInt(1, idSeance);
            bpmMaxMinStatement.setInt(2, idSeance);
            ResultSet rs = bpmMaxMinStatement.executeQuery();
            while (rs.next()) {
                res[0] = rs.getInt("MAX");
                res[1] = rs.getInt("MIN");
            }
        } catch (Exception err) {
            System.out.println(err);
        }
        return res;
    }

    public LinkedList<double[]> getBpmSeance(int idSeance) {
        String query = "SELECT freqCardiaque, dateMesure FROM Mesure WHERE idSeance = ?";
        LinkedList<double[]> res = new LinkedList<double[]>();
        Date dateMesure;
        int secondeInitiale = 0;
        double[] valeur = {0, 0};
        try {
            PreparedStatement bpmMaxMinStatement = connection.prepareStatement(query);
            bpmMaxMinStatement.setInt(1, idSeance);
            ResultSet rs = bpmMaxMinStatement.executeQuery();
            if (rs.next()) { // Première mesure
                dateMesure = new Date(rs.getTimestamp("dateMesure").getTime());
                secondeInitiale = (int) (dateMesure.getTime() / 1000);
                valeur[0] = 0;
                valeur[1] = rs.getInt("freqCardiaque");
                res.add(valeur);
            }
            while (rs.next()) {
                dateMesure = new Date(rs.getTimestamp("dateMesure").getTime());
                valeur = new double[2];
                valeur[0] = (int) ((dateMesure.getTime() / 1000) - secondeInitiale);
                valeur[1] = (int) rs.getInt("freqCardiaque");
                res.add(valeur);
            }
        } catch (Exception err) {
            System.out.println(err);
        }
        return res;
    }

    public LinkedList<Double> getSevenLastAllures(int idUser) {
        // Allures en min/km
        LinkedList<Double> res = new LinkedList<Double>();
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT TIMESTAMPDIFF(minute, dateDebut, dateFin)/distanceParcourue as allure FROM Seance WHERE idUtilisateur=? AND dateFin IS NOT NULL ORDER BY dateDebut DESC LIMIT 7");
            ps.setInt(1, idUser);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                res.add(rs.getDouble("allure"));
            }
        } catch (SQLException err) {
            System.out.println(err);
        }
        return res;
    }

    public int getPas(int idSeance) {
        String query1 = "SELECT nbPas FROM Mesure WHERE idSeance = ? ORDER BY dateMesure DESC LIMIT 1";
        String query2 = "SELECT nbPas FROM Mesure WHERE idSeance = ? ORDER BY dateMesure ASC LIMIT 1";
        int premierPas = 0;
        int dernierPas = 0;
        try {
            PreparedStatement nbPasStatement = connection.prepareStatement(query1);
            nbPasStatement.setInt(1, idSeance);
            ResultSet rs = nbPasStatement.executeQuery();
            while (rs.next()) {
                dernierPas = rs.getInt("nbPas");
            }

            nbPasStatement = connection.prepareStatement(query2);
            nbPasStatement.setInt(1, idSeance);
            rs = nbPasStatement.executeQuery();
            while (rs.next()) {
                premierPas = rs.getInt("nbPas");
            }
        } catch (Exception err) {
            System.out.println(err);
        }
        return (dernierPas - premierPas);
    }

    public LinkedList<Course> courses(int idUser, int mode) {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM HH:mm");
        LinkedList<Course> res = new LinkedList<Course>();
        String query = "";
        switch (mode) {
            case 1:
                query = "SELECT dateDebut, dateFin, distanceParcourue FROM Seance WHERE idUtilisateur = ? AND dateFin IS NOT NULL ORDER BY TIMESTAMPDIFF(SECOND, dateDebut,dateFin) DESC LIMIT 6";
                break;
            case 2:
                query = "SELECT dateDebut, dateFin, distanceParcourue FROM Seance WHERE idUtilisateur = ? AND dateFin IS NOT NULL ORDER BY (TIMESTAMPDIFF(SECOND, dateDebut,dateFin)/distanceParcourue) ASC LIMIT 6";
                break;
            case 3:
                query = "SELECT dateDebut, dateFin, distanceParcourue FROM Seance WHERE idUtilisateur = ? AND dateFin IS NOT NULL ORDER BY distanceParcourue DESC LIMIT 6";
                break;
        }
        try {
            PreparedStatement coursesStatement = connection.prepareStatement(query);
            coursesStatement.setInt(1, idUser);
            ResultSet rs = coursesStatement.executeQuery();
            while (rs.next()) {
                Date debut = new Date(rs.getTimestamp("dateDebut").getTime());
                Date fin = debut;
                if (rs.getTimestamp("dateFin") != null) {
                    fin = new Date(rs.getTimestamp("dateFin").getTime());
                }
                int duree = (int) (fin.getTime() - debut.getTime()) / 1000;
                res.add(new Course(dateFormat.format(debut), (float) rs.getDouble("distanceParcourue"), duree));
            }
        } catch (Exception err) {
            System.out.println(err);
        }
        return res;
    }

    public static void filtrage(int idSeance) {
        // filtrage vitesse à 20km/h
        String query = "SELECT vitesseInstant, dateMesure FROM Mesure WHERE idSeance = ?";
        ArrayList<Float> vitesses = new ArrayList<Float>();
        ArrayList<Timestamp> date = new ArrayList<Timestamp>();
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idSeance);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                vitesses.add(rs.getFloat("vitesseInstant"));
                date.add(rs.getTimestamp("dateMesure"));
            }
        } catch (Exception err) {
            System.out.println(err);
        }
        for (int i = 1; i < vitesses.size(); i++) {
            if (vitesses.get(i) >= 20) {
                vitesses.set(i, vitesses.get(i - 1));
            }
        }
        try {
            PreparedStatement ps = connection.prepareStatement("UPDATE Mesure SET vitesseInstant = ? WHERE dateMesure = ?");
            for (int i = 0; i < vitesses.size(); i++) {
                ps.setFloat(1, vitesses.get(i));
                ps.setTimestamp(2, date.get(i));
                ps.executeUpdate();
            }

        } catch (Exception err) {
            System.out.println(err);
        }
    }

    public LinkedList<Utilisateur> utilisateurs(int mode) {
        LinkedList<Utilisateur> res = new LinkedList<Utilisateur>();
        String query = "";
        switch (mode) {
            case 1:
                query = "SELECT nom, SUM(distanceParcourue) distance, SUM(TIMESTAMPDIFF(second,dateDebut,dateFin)) duree\n"
                        + "FROM Utilisateur u, Seance s WHERE u.idUtilisateur = s.idUtilisateur AND dateFin IS NOT NULL \n"
                        + "GROUP BY(u.idUtilisateur)\n"
                        + "ORDER BY duree DESC";
                break;
            case 2:
                query = "SELECT nom, SUM(distanceParcourue) distance, SUM(TIMESTAMPDIFF(second,dateDebut,dateFin)) duree\n"
                        + "FROM Utilisateur u, Seance s WHERE u.idUtilisateur = s.idUtilisateur AND dateFin IS NOT NULL \n"
                        + "GROUP BY(u.idUtilisateur)\n"
                        + "ORDER BY (SUM(TIMESTAMPDIFF(second,dateDebut,dateFin))/SUM(distanceParcourue)) ASC";
                break;
            case 3:
                query = "SELECT nom, SUM(distanceParcourue) distance, SUM(TIMESTAMPDIFF(second,dateDebut,dateFin)) duree\n"
                        + "FROM Utilisateur u, Seance s WHERE u.idUtilisateur = s.idUtilisateur AND dateFin IS NOT NULL \n"
                        + "GROUP BY(u.idUtilisateur)\n"
                        + "ORDER BY distance DESC";
                break;
        }
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String nom = rs.getString("nom");
                float distance = Float.parseFloat(Double.toString(rs.getDouble("distance")));
                int duree = rs.getInt("duree");
                res.add(new Utilisateur(nom, distance, duree));
            }
        } catch (Exception err) {
            System.out.println(err);
        }
        return res;
    }

    public LinkedList[] getLatLong(int idSeance) {
        String query = "SELECT latitude,longitude FROM Mesure WHERE idSeance = ?";
        LinkedList[] res = new LinkedList[2];
        LinkedList<Double> lat = new LinkedList<Double>();
        LinkedList<Double> longi = new LinkedList<Double>();
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idSeance);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (rs.getDouble("latitude") > 1 && rs.getDouble("longitude") > 1) { // filtrage
                    lat.add(rs.getDouble("latitude"));
                    longi.add(rs.getDouble("longitude"));
                }

            }
        } catch (Exception err) {
            System.out.println(err);
        }
        res[0] = lat;
        res[1] = longi;
        if (res[0].isEmpty()) {
            res[0] = new LinkedList<Double>();
            res[1] = new LinkedList<Double>();
            res[0].add(0.0);
            res[1].add(1.0);
        }
        return res;
    }

    public String[] getDureeVitesseSept(int idUser) {
        String[] res = new String[2];
        double duree = 0;
        double dist = 0;
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT TIMESTAMPDIFF(second,dateDebut,dateFin) duree, distanceParcourue FROM Seance WHERE idUtilisateur = ? AND TIMESTAMPDIFF(second,dateDebut,dateFin) IS NOT NULL LIMIT 7;");
            ps.setInt(1, idUser);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                duree += rs.getInt("duree");
                dist += rs.getDouble("distanceParcourue");
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        double dureeHeure = duree / 3600;
        int vMoy = (int) (dist / dureeHeure);
        res[0] = Double.toString(dureeHeure);
        res[1] = Integer.toString(vMoy);
        return res;
    }

    public int getLastSeanceLive(int idUser) {
        // renvoie l'idSeance si une seance est en cours, -1 sinon
        int res = -1;
        try {
            String query = "SELECT idSeance\n"
                    + "FROM Seance\n"
                    + "WHERE dateFin IS NULL AND idUtilisateur = ? AND DAY(CURDATE()) = DAY(dateDebut) AND MONTH(CURDATE())= MONTH(dateDebut)\n"
                    + "ORDER BY dateDebut DESC\n"
                    + "LIMIT 1";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idUser);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                res = rs.getInt("idSeance");

            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return res;
    }

    public LinkedList<double[]> get100bpm(int idSeance) {
        LinkedList<double[]> res = new LinkedList<double[]>();
        try {
            String query = "SELECT m.freqCardiaque bpm, TIMESTAMPDIFF(second,p.dateMesure,m.dateMesure) temps\n"
                    + "FROM Mesure AS m, (SELECT dateMesure FROM Mesure WHERE idSeance=? ORDER BY dateMesure ASC LIMIT 1) AS p\n"
                    + "WHERE m.idSeance = ?\n"
                    + "ORDER BY m.dateMesure DESC LIMIT 100";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idSeance);
            ps.setInt(2, idSeance);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                double[] val = new double[2];
                val[0] = rs.getInt("temps");
                val[1] = rs.getInt("bpm");
                res.add(val);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        Collections.reverse(res);
        if (res.isEmpty()) {
            double[] vv = {0, 0};
            res.add(vv);
        }
        return res;
    }

    public LinkedList<double[]> get100Pas(int idSeance) {
        LinkedList<double[]> res = new LinkedList<double[]>();
        try {
            String query = "SELECT (CAST(m.nbPas AS SIGNED) - p.nbPas) pas , TIMESTAMPDIFF(second, p.dateMesure, m.dateMesure) temps\n"
                    + "FROM Mesure as m, (SELECT CAST(nbPas AS SIGNED) nbPas, dateMesure  FROM Mesure WHERE idSeance = ? ORDER BY dateMesure ASC LIMIT 1) as p\n"
                    + "WHERE m.idSeance=?\n"
                    + "ORDER BY m.dateMesure DESC LIMIT 100;";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idSeance);
            ps.setInt(2, idSeance);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                double[] val = new double[2];
                val[0] = rs.getInt("temps");
                val[1] = rs.getInt("pas");
                res.add(val);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        Collections.reverse(res);
        if (res.isEmpty()) {
            double[] vv = {0, 0};
            res.add(vv);
        }
        return res;
    }

    public int[] getBPMPerf(LinkedList<double[]> bpm, int FCmax) {
        int[] res = new int[4];
        res[0] = 0;
        res[1] = 0;
        res[2] = 0;
        res[3] = 0;
        for (double[] d : bpm) {
            double v = d[1];
            if (v > 0.9 * FCmax) {
                res[3]++;
            } else if (v > 0.8 * FCmax) {
                res[2]++;
            } else if (v > 0.65 * FCmax) {
                res[1]++;
            } else {
                res[0]++;
            }
        }
        return res;
    }
}
