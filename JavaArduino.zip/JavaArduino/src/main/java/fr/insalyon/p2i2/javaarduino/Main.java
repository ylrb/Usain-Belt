package fr.insalyon.p2i2.javaarduino;

import fr.insalyon.p2i2.javaarduino.tdtp.TD1;
import fr.insalyon.p2i2.javaarduino.util.Console;
import java.io.IOException;

public class Main {

    public static TD1 td1 = new TD1();
    public static final Console console = new Console();

    public static void main(String[] args) {

        try {
            td1.connexionBD();
            td1.creerRequetesParametrees();
            
            LecteurArduino TA = new LecteurArduino();
            // écrire "stop" dans la console pour aller à la ligne suivante
            
            td1.fermetureConnexionBD();

        } catch (IOException ex) {
            console.log(ex);
        } catch (Exception err) {
            System.out.println(err);
        }

    }

}
